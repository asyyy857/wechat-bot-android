// dsh-vscreen —— 把「受信任虚拟屏」的取画面 / 操作能力做成 DSH 原生工具。
//
// 方案与两个守护（dsh.VsDaemon / dsh.ShellDaemon）由群友「如月雨露」制作，
// 本插件是随 App 分发的客户端：**只做请求转发**，一行权限判断都不做 ——
// 边界全在 App 与守护那边（守护只绑回环 + 每个请求校验 X-Token）。
//
// 三条通道，各管一段：
//   · :18240（虚拟屏守护）—— 列屏 / 取帧 / 改分辨率 / 把应用放上虚拟屏；
//   · :18242（命令端点守护）—— 以 shell 身份跑命令（点按就是 `input -d <id> tap x y`）；
//   · :3099（App 手机控制桥）—— 唯一能"把守护拉起来"的地方（它走 Shizuku，shell 身份）。
//
// 为什么点按要绕 :18242 而不是让守护自己实现：`input` 是系统命令，
// shell 身份直接就能跑，而且 `input -d <displayId>` 的坐标语义与虚拟屏一致 ——
// 守护再实现一套注入反而多一份要维护的代码（文档里那条"进程内注入"至今也没落地）。
//
// 零第三方依赖：插件随 APK 附带、在离线容器里安装，多一个依赖就多一个装不上的理由。
import fs from 'node:fs'
import http from 'node:http'
import path from 'node:path'
import os from 'node:os'
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'vscreen'
export const inject = ['tools']

const PORT_VSD = 18240
const PORT_SHD = 18242
const PORT_BRIDGE = 3099

/** token 由 App 写进容器：/run/dsh-vsd/token（App 每次启动容器重写一份）。 */
const TOKEN_FILES = ['/run/dsh-vsd/token', '/sdcard/dsh/.vsd-token']
/** 手机控制桥的 token（只有"拉起守护"这一步要它）。 */
const BRIDGE_TOKEN_FILES = ['/run/dsh-phone/token', '/sdcard/dsh/.phone-token']

function readFirst(files) {
  for (const p of files) {
    try {
      const t = fs.readFileSync(p, 'utf8').trim()
      if (t) return t
    } catch (e) { /* 试下一个 */ }
  }
  return ''
}

function token() {
  const t = readFirst(TOKEN_FILES)
  if (!t) throw new Error('读不到虚拟屏 token（/run/dsh-vsd/token）—— 先调 vscreen_ensure 装一次')
  return t
}

/** 通用 HTTP：返回 { code, headers, body(Buffer) }。 */
function req(port, apiPath, { method = 'GET', body = null, timeoutMs = 15000, tok = null } = {}) {
  return new Promise((resolve, reject) => {
    const headers = {}
    if (tok) headers['X-Token'] = tok
    if (body !== null && body !== undefined) {
      headers['Content-Type'] = 'text/plain; charset=utf-8'
      headers['Content-Length'] = Buffer.byteLength(body)
    }
    const r = http.request({ host: '127.0.0.1', port, path: apiPath, method, headers, timeout: timeoutMs },
      (res) => {
        const chunks = []
        res.on('data', (d) => chunks.push(d))
        res.on('end', () => resolve({ code: res.statusCode, body: Buffer.concat(chunks) }))
      })
    r.on('error', (e) => reject(new Error('连不上 127.0.0.1:' + port + '（' + e.message + '）')))
    r.on('timeout', () => r.destroy(new Error('响应超时')))
    if (body !== null && body !== undefined) r.write(body)
    r.end()
  })
}

/** 取 JSON 文本（守护没起来 / 没鉴权时给出人话）。 */
async function vsGet(apiPath) {
  const res = await req(PORT_VSD, apiPath, { tok: token() })
  if (res.code === 403) throw new Error('守护拒绝了请求（X-Token 不对）—— 重新 vscreen_ensure 一次')
  if (res.code !== 200) throw new Error('守护返回 HTTP ' + res.code)
  return res.body.toString('utf8')
}

/** 走 :18242 以 shell 身份跑一条命令。 */
async function shd(cmd) {
  const res = await req(PORT_SHD, '/exec', { method: 'POST', body: cmd, timeoutMs: 60000, tok: token() })
  if (res.code === 403) throw new Error('命令端点拒绝了请求（X-Token 不对）')
  return res.body.toString('utf8')
}

/** 走 App 桥（拉起/停止守护用；那一步只有 App 有 shell 身份）。 */
async function bridge(op) {
  const t = readFirst(BRIDGE_TOKEN_FILES)
  if (!t) throw new Error('读不到手机控制桥的 token（/run/dsh-phone/token）—— App 在运行吗？')
  const res = await req(PORT_BRIDGE, '/vscreen?token=' + encodeURIComponent(t) + '&op=' + encodeURIComponent(op),
    { timeoutMs: 120000 })
  const text = res.body.toString('utf8')
  if (/^ERROR/.test(text)) throw new Error(text.trim())
  return text
}

// ───────────────────────── v1.1 的"别跳屏"自动化 ─────────────────────────
//
// 这一节是 v1.1 文档 §6 / vscreen.sh 里最值钱的那部分经验，原来只在群友的
// shell 脚本里，插件这边没有。三条规则（全部来自实测，不是推断）：
//
//   ① 【前置闸门】目标应用如果**已经在主屏前台**，它有主屏任务，
//      `am start --display` 会被 system 忽略并并回主屏那个任务 → 直接拒绝，连试都不试。
//   ② 【落屏校验】启动后必须回查它到底落在哪块屏；发现回落到主屏就立刻 force-stop，
//      绝不把应用留在用户正在看的屏上（文档 L1232-L1261）。
//   ③ 【点击后自动拉回】应用内跳页会把**整个 root task 搬回主屏**
//      （实测 displayId 34 → 0）→ 点完 tap 立刻用 `am display move-stack` 拉回来。
//      有一个**永不搬运名单**（搬它会重启宿主 App 界面），命中就跳过。

/** 永不搬运名单（文档 L1270：搬它会让宿主 App 的 Activity 重建 → 界面重启）。 */
const NEVER_MOVE_FILE = '/sdcard/dsh/.vscreen-never-move'
/** 上次拉起来的包名（与文档的 /tmp/.vscreen-lastpkg 等价，换成容器里可写的位置）。 */
const LAST_PKG_FILE = '/run/dsh-vsd/last-pkg'

function readNeverMove() {
  try {
    return fs.readFileSync(NEVER_MOVE_FILE, 'utf8')
      .split('\n').map((s) => s.trim()).filter(Boolean)
  } catch (e) { return [] }
}

function rememberPkg(pkg) {
  try {
    fs.mkdirSync('/run/dsh-vsd', { recursive: true })
    fs.writeFileSync(LAST_PKG_FILE, pkg + '\n')
  } catch (e) { /* 记不住不影响功能，只是 pull 会不知道搬谁 */ }
}

function lastPkg() {
  try { return fs.readFileSync(LAST_PKG_FILE, 'utf8').trim() } catch (e) { return '' }
}

/** 主屏当前前台的包名（拿不到返回空串）。 */
async function foregroundPkg() {
  try {
    const out = await shd("dumpsys activity activities | grep -m1 topResumedActivity | grep -oE '[a-zA-Z][a-zA-Z0-9_.]*/' | head -1 | tr -d '/'")
    const m = out.match(/[a-zA-Z][a-zA-Z0-9_.]*/)
    return m ? m[0] : ''
  } catch (e) { return '' }
}

/** 某块虚拟屏上有没有这个包的任务（文档 L1233 的 ONTGT 检查）。 */
async function tasksOnDisplay(displayId, pkg) {
  try {
    const out = await shd('dumpsys activity activities | grep -A400 "Display #' + displayId + '" | grep -c "' + pkg + '"')
    const m = out.match(/\d+/)
    return m ? Number(m[0]) : 0
  } catch (e) { return 0 }
}

/**
 * 找到这个包的 RootTask id（文档 L1271 的 awk 那段）。
 *
 * 为什么要找 RootTask：跳页是把**整个 root task** 搬走，所以拉回也得按 task 搬，
 * 按 Activity 或包名是搬不回来的。
 */
async function rootTaskOf(pkg) {
  try {
    const out = await shd('cmd activity stack list 2>/dev/null | awk -v pkg="' + pkg +
      '" \'/^RootTask id=/{rt=$2} $0 ~ ("taskId=[0-9]+: " pkg "/") {print rt; exit}\' | sed "s/id=//"')
    const m = out.match(/\d+/)
    return m ? m[0] : ''
  } catch (e) { return '' }
}

/**
 * 把包名对应的 RootTask 搬到指定屏。
 * @return 空串 = 搬成功（或本来就在正确位置）；非空 = 给用户看的原因
 */
async function moveToDisplay(pkg, displayId) {
  const rt = await rootTaskOf(pkg)
  if (!rt) return '没找到 ' + pkg + ' 的任务（可能已经被结束）'
  await shd('am display move-stack ' + rt + ' ' + displayId)
  return ''
}

/** force_resizable_activities 有没有开（没开的话不可缩放的应用会回落主屏）。 */
async function resizableOk() {
  try {
    const out = await shd('settings get global force_resizable_activities')
    return out.trim() === '1'
  } catch (e) { return true }   // 查不到就别吓唬用户
}

/**
 * 点击后的看门狗：应用被跳回主屏就拉回来（文档 L1286-L1307 的"最终解"）。
 *
 * <p>设计取舍：**做得对用户无感、只在真的出事时才说话**。
 * 所以 tap 里直接内置，但不做成独立工具 —— 让 agent 自己记得每次点完都调一次
 * 是不现实的（那正是"插件不好用"的来源）。
 *
 * @return 空串 = 什么都没发生；非空 = 值得告诉用户的一行话
 */
async function pullBackIfJumped(displayId) {
  const pkg = lastPkg()
  if (!pkg) return ''
  if (readNeverMove().indexOf(pkg) >= 0) return ''      // 名单里的不动
  const fg = await foregroundPkg()
  if (fg !== pkg) return ''                             // 没跳，什么都没发生
  const why = await moveToDisplay(pkg, displayId)
  if (why) return '⚠️ ' + pkg + ' 跳回主屏且拉不回来（' + why + '）—— 已交给用户处理'
  return '↻ ' + pkg + ' 跳回主屏了，已自动拉回 display ' + displayId
}


/** 从 /list 的 JSON 里找第 i 块屏的 displayId。 */
function displayIdOf(listJson, i) {
  let arr
  try { arr = JSON.parse(listJson) } catch (e) { throw new Error('守护返回的不是 JSON：' + listJson.slice(0, 200)) }
  if (!Array.isArray(arr) || !arr.length) throw new Error('守护在跑，但一块屏都没有：' + listJson.slice(0, 200))
  const hit = arr.find((s) => Number(s.i) === Number(i))
  if (!hit) throw new Error('没有第 ' + i + ' 块屏（现在有 ' + arr.length + ' 块：' +
    arr.map((s) => s.i + '→displayId ' + s.displayId).join(', ') + '）')
  return hit
}

/** 取帧并存成 jpg，返回容器里的路径（拿到后直接 read_image 读它）。 */
async function shot(i, w) {
  const listJson = await vsGet('/list')
  const slot = displayIdOf(listJson, i)
  const q = w ? ('?w=' + Number(w)) : ''
  const res = await req(PORT_VSD, '/' + slot.i + '/frame' + q, { tok: token(), timeoutMs: 20000 })
  if (res.code !== 200) throw new Error('取帧失败：HTTP ' + res.code + ' ' + res.body.toString('utf8').slice(0, 120))
  if (res.body.length < 1024) throw new Error('这一帧还没准备好（' + res.body.toString('utf8').slice(0, 60) + '），稍等半秒再试')
  const dir = path.join(os.homedir(), '.dsh-vscreen')
  fs.mkdirSync(dir, { recursive: true })
  const file = path.join(dir, 'shot-' + slot.i + '-' + Date.now() + '.jpg')
  fs.writeFileSync(file, res.body)
  return file
}

const ensureNote = '如果报「连不上 127.0.0.1:18240」，先调一次 vscreen_ensure（它会借 App 的 Shizuku 权限把守护装好并拉起）。'

function tool(spec) {
  return defineTool({
    name: spec.name,
    description: spec.description,
    parameters: spec.parameters || {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: String(value) }],
    },
    async execute(args) {
      return await spec.run(args || {})
    },
  })
}

export function apply(ctx) {
  const tools = [
    tool({
      name: 'vscreen_ensure',
      description: '确保「受信任虚拟屏」守护在跑：没装就装、没起就起（需要用户已授权 Shizuku）。'
        + '任何 vscreen_* 工具报"连不上"时先调它。手机重启后守护会全灭，也要重新调一次。',
      run: async () => await bridge('ensure'),
    }),
    tool({
      name: 'vscreen_list',
      description: '列出虚拟屏：每块屏的 displayId、分辨率、已经取过多少帧（帧数不动 = 画面是静止的）。'
        + '后台跑应用、看它的画面之前先调这个确认守护在跑。' + ensureNote,
      run: async () => await vsGet('/list'),
    }),
    tool({
      name: 'vscreen_shot',
      description: '取某块虚拟屏当前画面并存成 jpg，返回文件路径 —— **拿到路径后必须用 read_image 读它**，'
        + '否则你看不到画面。文字界面也可以先用 read_image 看，再决定点哪里。'
        + '参数 i 是屏序号（默认 0），w 是最大宽度（越小越快、token 越少，默认不缩放）。',
      parameters: {
        i: { type: 'number', description: '屏序号，默认 0' },
        w: { type: 'number', description: '缩放到的最大宽度（像素），例如 720；不填=原分辨率' },
      },
      run: async (a) => '图片已保存：' + (await shot(a.i || 0, a.w)) + '\n（用 read_image 读这个路径）',
    }),
    tool({
      name: 'vscreen_tap',
      description: '按坐标点击某块虚拟屏。坐标是该屏自己的坐标系（左上角 0,0）—— '
        + '从 vscreen_shot 的画面或 vscreen_info 里判断。' + ensureNote,
      parameters: {
        x: { type: 'number', required: true, description: '横坐标（像素）' },
        y: { type: 'number', required: true, description: '纵坐标（像素）' },
        i: { type: 'number', description: '屏序号，默认 0' },
      },
      run: async (a) => {
        const slot = displayIdOf(await vsGet('/list'), a.i || 0)
        const out = await shd('input -d ' + slot.displayId + ' tap ' + Number(a.x) + ' ' + Number(a.y))
        // 点击后看门狗：跳页会把整个 root task 搬回主屏（实测 displayId 34 → 0）。
        // 默认等 1.5 秒再查一次，只有真的跳了才多花时间；没跳就什么都没发生。
        if (a.watch === false) return out
        await new Promise((r) => setTimeout(r, 1500))
        const note = await pullBackIfJumped(slot.displayId)
        return note ? out + '\n' + note : out
      },
    }),
    tool({
      name: 'vscreen_pull',
      description: '把最近一次 vscreen_app 拉起的应用从主屏搬回虚拟屏 —— 治"应用内跳页后整个任务回到主屏"。'
        + 'vscreen_tap 已经内置了这个看门狗，只有在你自己 force-stop 过、或看门狗也没拉回来时才需要手动调。'
        + `/sdcard/dsh/.vscreen-never-move 里列出的包名永不搬运（搬它会重启宿主界面）。`,
      parameters: {
        i: { type: 'number', description: '目标屏序号，默认 0' },
      },
      run: async (a) => {
        const slot = displayIdOf(await vsGet('/list'), a.i || 0)
        const pkg = lastPkg()
        if (!pkg) throw new Error('不知道要搬哪个应用 —— 先用 vscreen_app 拉起一个')
        if (readNeverMove().indexOf(pkg) >= 0) {
          throw new Error('⛔ ' + pkg + ' 在永不搬运名单里（' + NEVER_MOVE_FILE + '）——搬它会重启界面，已拒绝')
        }
        const why = await moveToDisplay(pkg, slot.displayId)
        if (why) throw new Error('搬运失败：' + why)
        return '✅ 已把 ' + pkg + ' 搬到 display ' + slot.displayId
      },
    }),
    tool({
      name: 'vscreen_swipe',
      description: '在某块虚拟屏上从一点滑到另一点（滚动 / 翻页）。持续移动类（摇杆）需要多次调用。',
      parameters: {
        x1: { type: 'number', required: true },
        y1: { type: 'number', required: true },
        x2: { type: 'number', required: true },
        y2: { type: 'number', required: true },
        ms: { type: 'number', description: '滑动时长（毫秒），默认 300' },
        i: { type: 'number', description: '屏序号，默认 0' },
      },
      run: async (a) => {
        const slot = displayIdOf(await vsGet('/list'), a.i || 0)
        return await shd('input -d ' + slot.displayId + ' swipe ' + Number(a.x1) + ' ' + Number(a.y1)
          + ' ' + Number(a.x2) + ' ' + Number(a.y2) + ' ' + Number(a.ms || 300))
      },
    }),
    tool({
      name: 'vscreen_key',
      description: '给某块虚拟屏发按键。BACK 对副屏有效；HOME / POWER / VOLUME 由系统在**默认屏**处理，'
        + '在虚拟屏上一般没用（这也是文档里说音量键要禁用的原因）。不要用它去按物理屏的键。',
      parameters: {
        key: {
          type: 'string', required: true,
          enum: ['BACK', 'HOME', 'APP_SWITCH', 'ENTER', 'DEL', 'TAB', 'DPAD_UP', 'DPAD_DOWN', 'DPAD_LEFT', 'DPAD_RIGHT'],
        },
        i: { type: 'number', description: '屏序号，默认 0' },
      },
      run: async (a) => {
        const slot = displayIdOf(await vsGet('/list'), a.i || 0)
        return await shd('input -d ' + slot.displayId + ' keyevent ' + String(a.key))
      },
    }),
    tool({
      name: 'vscreen_app',
      description: '把某个应用启动到虚拟屏上（后台跑，不跳屏、不抢前台）。'
        + '参数 pkg 是包名，act 可选（例如 .MainActivity）。'
        + '三条硬规则（v1.1 实测得出，别绕过）：① 目标应用如果已经在你主屏前台，会被直接拒绝 —— '
        + '它有主屏任务时 `am start` 必会并回主屏；② 启动后会自动回查它落在哪块屏，'
        + '发现回落到主屏就立刻结束它，绝不留在你正在看的屏上；'
        + '③ 宿主 App（com.dshmobile.probe）永不搬上虚拟屏。'
        + '想开的应用不在白名单里？那是 phone 那套工具的边界，与虚拟屏无关（这条路不需要无障碍）。',
      parameters: {
        pkg: { type: 'string', required: true, description: '包名，例如 com.tencent.mm' },
        act: { type: 'string', description: 'Activity，可省略（省略则发 LAUNCHER）' },
        i: { type: 'number', description: '屏序号，默认 0' },
      },
      run: async (a) => {
        const pkg = String(a.pkg)
        const slot = displayIdOf(await vsGet('/list'), a.i || 0)
        const d = slot.displayId

        // ① 前置闸门：已经在主屏前台 → 直接拒绝（文档 L1207-L1214）
        const fg0 = await foregroundPkg()
        if (fg0 && fg0 === pkg) {
          throw new Error('⛔ ' + pkg + ' 现在就在你的主屏前台 —— 它有主屏任务，am start 必会并回主屏，已拒绝启动。'
            + '要操作它，请先自己把它退到后台，或改用物理屏的 phone 桥。')
        }

        // ② force_resizable_activities：没开的话不可缩放的应用会回落主屏（文档 L1222-L1228）
        let warn = ''
        if (!(await resizableOk())) {
          warn = '\n⚠️ force_resizable_activities 没开 —— 不可缩放的应用会回落到主屏。'
            + '开启命令：settings put global force_resizable_activities 1'
        }

        const target = a.act && String(a.act).length
          ? pkg + '/' + (String(a.act).charAt(0) === '.' ? pkg + a.act : String(a.act))
          : pkg
        // 先 force-stop 再起：让应用"哪都不存在"，这样 --display 一定会把新任务生在虚拟屏上，
        // 后续二级页面也全部留在副屏（与 v1.1 的 vscreen app 同一条路径）。
        await shd('am force-stop ' + pkg)
        await new Promise((r) => setTimeout(r, 800))
        const out = await shd('am start --display ' + d + ' -n ' + target)
        await new Promise((r) => setTimeout(r, 2000))

        // ③ 落屏校验：回落到主屏就立刻撤（文档 L1232-L1249）
        const fg1 = await foregroundPkg()
        if (fg1 && fg1 === pkg && fg0 !== pkg) {
          await shd('am force-stop ' + pkg)
          throw new Error('⛔ ' + pkg + ' 回落到你的主屏了（这个应用吃不到 --display）—— 已立刻强制结束，主屏已还原。'
            + warn)
        }
        const onTgt = await tasksOnDisplay(d, pkg)
        if (onTgt === 0) {
          await shd('am force-stop ' + pkg)
          throw new Error('⚠️ 没在 display ' + d + ' 上发现 ' + pkg + ' 的任务，可能落在别处；已强制结束以防占屏。' + warn)
        }

        rememberPkg(pkg)
        return out + '\n✅ ' + pkg + ' 已确认落在 display ' + d + ' 上（且未上主屏）' + warn
      },
    }),
  ]

  // 逐个注册并把结果写成自检文件：项目栽过"文件在仓库里却从没生效"的跟头，
  // 所以"装上了"和"工具真的注册成功"要分开留证据。
  let ok = 0
  const failed = []
  for (const t of tools) {
    try { ctx.tools.register(t); ok++ }
    catch (e) { failed.push(t.name + ': ' + (e && e.message ? e.message : String(e))) }
  }
  try {
    fs.mkdirSync('/sdcard/.dsh-phone', { recursive: true })
    fs.writeFileSync('/sdcard/.dsh-phone/vscreen-loaded.txt',
      'plugin=dsh-vscreen\n'
      + 'time=' + new Date().toISOString() + '\n'
      + 'tools=' + tools.length + '\n'
      + 'registered=' + ok + '\n'
      + 'failed=' + JSON.stringify(failed) + '\n'
      + 'names=' + tools.map((t) => t.name).join(',') + '\n')
  } catch (e) { /* 写不了自检文件不该让插件失效 */ }
}
